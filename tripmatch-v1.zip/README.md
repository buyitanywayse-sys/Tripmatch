# TripMatch

A group travel matching app that helps friends find destinations everyone wants to visit.

## Prototype
This first version includes:
- Landing page
- Trip preference form
- Destination swipe-style cards
- Like/pass flow
- Simple result screen

It is a front-end prototype. Group accounts, shared invite links, live flight/hotel data, database storage and payments are not included yet.

## Run
Open `index.html` in a browser, or deploy the repository with a static hosting provider.
